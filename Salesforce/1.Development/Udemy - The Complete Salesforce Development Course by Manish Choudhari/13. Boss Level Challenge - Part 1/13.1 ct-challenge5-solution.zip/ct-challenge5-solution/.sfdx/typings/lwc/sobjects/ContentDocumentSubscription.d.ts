declare module "@salesforce/schema/ContentDocumentSubscription.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/ContentDocumentSubscription.User" {
  const User:any;
  export default User;
}
declare module "@salesforce/schema/ContentDocumentSubscription.UserId" {
  const UserId:any;
  export default UserId;
}
declare module "@salesforce/schema/ContentDocumentSubscription.ContentDocument" {
  const ContentDocument:any;
  export default ContentDocument;
}
declare module "@salesforce/schema/ContentDocumentSubscription.ContentDocumentId" {
  const ContentDocumentId:any;
  export default ContentDocumentId;
}
declare module "@salesforce/schema/ContentDocumentSubscription.IsCommentSub" {
  const IsCommentSub:boolean;
  export default IsCommentSub;
}
declare module "@salesforce/schema/ContentDocumentSubscription.IsDocumentSub" {
  const IsDocumentSub:boolean;
  export default IsDocumentSub;
}
