declare module "@salesforce/schema/CustomHttpHeader.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/CustomHttpHeader.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/CustomHttpHeader.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/CustomHttpHeader.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/CustomHttpHeader.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/CustomHttpHeader.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/CustomHttpHeader.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/CustomHttpHeader.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
declare module "@salesforce/schema/CustomHttpHeader.Parent" {
  const Parent:any;
  export default Parent;
}
declare module "@salesforce/schema/CustomHttpHeader.ParentId" {
  const ParentId:any;
  export default ParentId;
}
declare module "@salesforce/schema/CustomHttpHeader.HeaderFieldName" {
  const HeaderFieldName:string;
  export default HeaderFieldName;
}
declare module "@salesforce/schema/CustomHttpHeader.HeaderFieldValue" {
  const HeaderFieldValue:string;
  export default HeaderFieldValue;
}
declare module "@salesforce/schema/CustomHttpHeader.IsActive" {
  const IsActive:boolean;
  export default IsActive;
}
declare module "@salesforce/schema/CustomHttpHeader.Description" {
  const Description:string;
  export default Description;
}
