declare module "@salesforce/schema/QuickTextHistory.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/QuickTextHistory.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/QuickTextHistory.QuickText" {
  const QuickText:any;
  export default QuickText;
}
declare module "@salesforce/schema/QuickTextHistory.QuickTextId" {
  const QuickTextId:any;
  export default QuickTextId;
}
declare module "@salesforce/schema/QuickTextHistory.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/QuickTextHistory.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/QuickTextHistory.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/QuickTextHistory.Field" {
  const Field:string;
  export default Field;
}
declare module "@salesforce/schema/QuickTextHistory.OldValue" {
  const OldValue:any;
  export default OldValue;
}
declare module "@salesforce/schema/QuickTextHistory.NewValue" {
  const NewValue:any;
  export default NewValue;
}
