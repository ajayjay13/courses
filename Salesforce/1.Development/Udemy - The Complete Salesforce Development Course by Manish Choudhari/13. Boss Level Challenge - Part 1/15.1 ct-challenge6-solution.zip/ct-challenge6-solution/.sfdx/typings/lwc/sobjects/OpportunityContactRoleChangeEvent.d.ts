declare module "@salesforce/schema/OpportunityContactRoleChangeEvent.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/OpportunityContactRoleChangeEvent.ReplayId" {
  const ReplayId:string;
  export default ReplayId;
}
declare module "@salesforce/schema/OpportunityContactRoleChangeEvent.ChangeEventHeader" {
  const ChangeEventHeader:any;
  export default ChangeEventHeader;
}
declare module "@salesforce/schema/OpportunityContactRoleChangeEvent.Opportunity" {
  const Opportunity:any;
  export default Opportunity;
}
declare module "@salesforce/schema/OpportunityContactRoleChangeEvent.OpportunityId" {
  const OpportunityId:any;
  export default OpportunityId;
}
declare module "@salesforce/schema/OpportunityContactRoleChangeEvent.Contact" {
  const Contact:any;
  export default Contact;
}
declare module "@salesforce/schema/OpportunityContactRoleChangeEvent.ContactId" {
  const ContactId:any;
  export default ContactId;
}
declare module "@salesforce/schema/OpportunityContactRoleChangeEvent.Role" {
  const Role:string;
  export default Role;
}
declare module "@salesforce/schema/OpportunityContactRoleChangeEvent.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/OpportunityContactRoleChangeEvent.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/OpportunityContactRoleChangeEvent.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/OpportunityContactRoleChangeEvent.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/OpportunityContactRoleChangeEvent.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/OpportunityContactRoleChangeEvent.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
