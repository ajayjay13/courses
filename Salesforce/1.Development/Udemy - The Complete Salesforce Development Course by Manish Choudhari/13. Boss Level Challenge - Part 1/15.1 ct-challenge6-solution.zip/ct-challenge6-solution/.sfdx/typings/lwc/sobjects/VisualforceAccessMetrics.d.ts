declare module "@salesforce/schema/VisualforceAccessMetrics.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/VisualforceAccessMetrics.MetricsDate" {
  const MetricsDate:any;
  export default MetricsDate;
}
declare module "@salesforce/schema/VisualforceAccessMetrics.ApexPage" {
  const ApexPage:any;
  export default ApexPage;
}
declare module "@salesforce/schema/VisualforceAccessMetrics.ApexPageId" {
  const ApexPageId:any;
  export default ApexPageId;
}
declare module "@salesforce/schema/VisualforceAccessMetrics.Profile" {
  const Profile:any;
  export default Profile;
}
declare module "@salesforce/schema/VisualforceAccessMetrics.ProfileId" {
  const ProfileId:any;
  export default ProfileId;
}
declare module "@salesforce/schema/VisualforceAccessMetrics.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
declare module "@salesforce/schema/VisualforceAccessMetrics.DailyPageViewCount" {
  const DailyPageViewCount:number;
  export default DailyPageViewCount;
}
declare module "@salesforce/schema/VisualforceAccessMetrics.LogDate" {
  const LogDate:any;
  export default LogDate;
}
