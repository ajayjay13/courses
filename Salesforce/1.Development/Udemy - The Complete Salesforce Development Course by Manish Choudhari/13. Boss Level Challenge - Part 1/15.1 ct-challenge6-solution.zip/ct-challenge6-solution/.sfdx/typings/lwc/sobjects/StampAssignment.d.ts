declare module "@salesforce/schema/StampAssignment.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/StampAssignment.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/StampAssignment.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/StampAssignment.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/StampAssignment.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/StampAssignment.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/StampAssignment.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/StampAssignment.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/StampAssignment.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
declare module "@salesforce/schema/StampAssignment.Stamp" {
  const Stamp:any;
  export default Stamp;
}
declare module "@salesforce/schema/StampAssignment.StampId" {
  const StampId:any;
  export default StampId;
}
declare module "@salesforce/schema/StampAssignment.Subject" {
  const Subject:any;
  export default Subject;
}
declare module "@salesforce/schema/StampAssignment.SubjectId" {
  const SubjectId:any;
  export default SubjectId;
}
