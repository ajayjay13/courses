declare module "@salesforce/schema/Vote.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/Vote.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/Vote.Parent" {
  const Parent:any;
  export default Parent;
}
declare module "@salesforce/schema/Vote.ParentId" {
  const ParentId:any;
  export default ParentId;
}
declare module "@salesforce/schema/Vote.Type" {
  const Type:string;
  export default Type;
}
declare module "@salesforce/schema/Vote.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/Vote.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/Vote.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/Vote.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/Vote.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/Vote.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/Vote.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
