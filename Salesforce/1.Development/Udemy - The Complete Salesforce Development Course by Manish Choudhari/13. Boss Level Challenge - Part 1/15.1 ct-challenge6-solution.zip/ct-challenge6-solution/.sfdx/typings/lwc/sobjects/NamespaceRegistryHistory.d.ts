declare module "@salesforce/schema/NamespaceRegistryHistory.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/NamespaceRegistryHistory.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/NamespaceRegistryHistory.NamespaceRegistry" {
  const NamespaceRegistry:any;
  export default NamespaceRegistry;
}
declare module "@salesforce/schema/NamespaceRegistryHistory.NamespaceRegistryId" {
  const NamespaceRegistryId:any;
  export default NamespaceRegistryId;
}
declare module "@salesforce/schema/NamespaceRegistryHistory.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/NamespaceRegistryHistory.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/NamespaceRegistryHistory.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/NamespaceRegistryHistory.Field" {
  const Field:string;
  export default Field;
}
declare module "@salesforce/schema/NamespaceRegistryHistory.OldValue" {
  const OldValue:any;
  export default OldValue;
}
declare module "@salesforce/schema/NamespaceRegistryHistory.NewValue" {
  const NewValue:any;
  export default NewValue;
}
