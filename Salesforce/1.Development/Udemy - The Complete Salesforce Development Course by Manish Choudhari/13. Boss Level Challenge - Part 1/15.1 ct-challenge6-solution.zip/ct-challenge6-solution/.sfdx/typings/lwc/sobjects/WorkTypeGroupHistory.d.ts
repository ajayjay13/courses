declare module "@salesforce/schema/WorkTypeGroupHistory.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/WorkTypeGroupHistory.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/WorkTypeGroupHistory.WorkTypeGroup" {
  const WorkTypeGroup:any;
  export default WorkTypeGroup;
}
declare module "@salesforce/schema/WorkTypeGroupHistory.WorkTypeGroupId" {
  const WorkTypeGroupId:any;
  export default WorkTypeGroupId;
}
declare module "@salesforce/schema/WorkTypeGroupHistory.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/WorkTypeGroupHistory.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/WorkTypeGroupHistory.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/WorkTypeGroupHistory.Field" {
  const Field:string;
  export default Field;
}
declare module "@salesforce/schema/WorkTypeGroupHistory.OldValue" {
  const OldValue:any;
  export default OldValue;
}
declare module "@salesforce/schema/WorkTypeGroupHistory.NewValue" {
  const NewValue:any;
  export default NewValue;
}
