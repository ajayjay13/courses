declare module "@salesforce/schema/MessagingEndUserHistory.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/MessagingEndUserHistory.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/MessagingEndUserHistory.MessagingEndUser" {
  const MessagingEndUser:any;
  export default MessagingEndUser;
}
declare module "@salesforce/schema/MessagingEndUserHistory.MessagingEndUserId" {
  const MessagingEndUserId:any;
  export default MessagingEndUserId;
}
declare module "@salesforce/schema/MessagingEndUserHistory.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/MessagingEndUserHistory.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/MessagingEndUserHistory.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/MessagingEndUserHistory.Field" {
  const Field:string;
  export default Field;
}
declare module "@salesforce/schema/MessagingEndUserHistory.OldValue" {
  const OldValue:any;
  export default OldValue;
}
declare module "@salesforce/schema/MessagingEndUserHistory.NewValue" {
  const NewValue:any;
  export default NewValue;
}
