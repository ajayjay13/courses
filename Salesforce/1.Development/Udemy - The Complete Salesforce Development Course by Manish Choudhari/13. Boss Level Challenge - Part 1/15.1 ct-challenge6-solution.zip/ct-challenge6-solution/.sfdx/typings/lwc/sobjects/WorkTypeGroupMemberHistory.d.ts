declare module "@salesforce/schema/WorkTypeGroupMemberHistory.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/WorkTypeGroupMemberHistory.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/WorkTypeGroupMemberHistory.WorkTypeGroupMember" {
  const WorkTypeGroupMember:any;
  export default WorkTypeGroupMember;
}
declare module "@salesforce/schema/WorkTypeGroupMemberHistory.WorkTypeGroupMemberId" {
  const WorkTypeGroupMemberId:any;
  export default WorkTypeGroupMemberId;
}
declare module "@salesforce/schema/WorkTypeGroupMemberHistory.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/WorkTypeGroupMemberHistory.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/WorkTypeGroupMemberHistory.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/WorkTypeGroupMemberHistory.Field" {
  const Field:string;
  export default Field;
}
declare module "@salesforce/schema/WorkTypeGroupMemberHistory.OldValue" {
  const OldValue:any;
  export default OldValue;
}
declare module "@salesforce/schema/WorkTypeGroupMemberHistory.NewValue" {
  const NewValue:any;
  export default NewValue;
}
