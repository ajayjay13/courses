declare module "@salesforce/schema/AggregateResult.Id" {
  const Id:any;
  export default Id;
}
