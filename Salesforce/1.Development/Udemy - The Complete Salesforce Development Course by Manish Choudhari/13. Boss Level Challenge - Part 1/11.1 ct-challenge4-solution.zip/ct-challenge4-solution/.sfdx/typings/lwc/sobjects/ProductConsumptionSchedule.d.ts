declare module "@salesforce/schema/ProductConsumptionSchedule.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/ProductConsumptionSchedule.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/ProductConsumptionSchedule.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/ProductConsumptionSchedule.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/ProductConsumptionSchedule.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/ProductConsumptionSchedule.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/ProductConsumptionSchedule.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/ProductConsumptionSchedule.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/ProductConsumptionSchedule.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
declare module "@salesforce/schema/ProductConsumptionSchedule.Product" {
  const Product:any;
  export default Product;
}
declare module "@salesforce/schema/ProductConsumptionSchedule.ProductId" {
  const ProductId:any;
  export default ProductId;
}
declare module "@salesforce/schema/ProductConsumptionSchedule.ConsumptionSchedule" {
  const ConsumptionSchedule:any;
  export default ConsumptionSchedule;
}
declare module "@salesforce/schema/ProductConsumptionSchedule.ConsumptionScheduleId" {
  const ConsumptionScheduleId:any;
  export default ConsumptionScheduleId;
}
