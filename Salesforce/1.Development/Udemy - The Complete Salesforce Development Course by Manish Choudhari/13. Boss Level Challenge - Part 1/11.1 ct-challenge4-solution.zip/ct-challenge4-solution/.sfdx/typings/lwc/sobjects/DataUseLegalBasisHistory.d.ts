declare module "@salesforce/schema/DataUseLegalBasisHistory.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/DataUseLegalBasisHistory.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/DataUseLegalBasisHistory.DataUseLegalBasis" {
  const DataUseLegalBasis:any;
  export default DataUseLegalBasis;
}
declare module "@salesforce/schema/DataUseLegalBasisHistory.DataUseLegalBasisId" {
  const DataUseLegalBasisId:any;
  export default DataUseLegalBasisId;
}
declare module "@salesforce/schema/DataUseLegalBasisHistory.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/DataUseLegalBasisHistory.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/DataUseLegalBasisHistory.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/DataUseLegalBasisHistory.Field" {
  const Field:string;
  export default Field;
}
declare module "@salesforce/schema/DataUseLegalBasisHistory.OldValue" {
  const OldValue:any;
  export default OldValue;
}
declare module "@salesforce/schema/DataUseLegalBasisHistory.NewValue" {
  const NewValue:any;
  export default NewValue;
}
