declare module "@salesforce/schema/UserPackageLicense.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/UserPackageLicense.PackageLicense" {
  const PackageLicense:any;
  export default PackageLicense;
}
declare module "@salesforce/schema/UserPackageLicense.PackageLicenseId" {
  const PackageLicenseId:any;
  export default PackageLicenseId;
}
declare module "@salesforce/schema/UserPackageLicense.User" {
  const User:any;
  export default User;
}
declare module "@salesforce/schema/UserPackageLicense.UserId" {
  const UserId:any;
  export default UserId;
}
declare module "@salesforce/schema/UserPackageLicense.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/UserPackageLicense.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/UserPackageLicense.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/UserPackageLicense.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/UserPackageLicense.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/UserPackageLicense.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/UserPackageLicense.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
