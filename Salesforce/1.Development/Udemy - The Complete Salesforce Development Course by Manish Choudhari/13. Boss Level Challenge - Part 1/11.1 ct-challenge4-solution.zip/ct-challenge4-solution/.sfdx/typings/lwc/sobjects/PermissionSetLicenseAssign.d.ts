declare module "@salesforce/schema/PermissionSetLicenseAssign.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/PermissionSetLicenseAssign.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/PermissionSetLicenseAssign.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/PermissionSetLicenseAssign.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/PermissionSetLicenseAssign.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/PermissionSetLicenseAssign.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/PermissionSetLicenseAssign.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/PermissionSetLicenseAssign.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/PermissionSetLicenseAssign.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
declare module "@salesforce/schema/PermissionSetLicenseAssign.PermissionSetLicense" {
  const PermissionSetLicense:any;
  export default PermissionSetLicense;
}
declare module "@salesforce/schema/PermissionSetLicenseAssign.PermissionSetLicenseId" {
  const PermissionSetLicenseId:any;
  export default PermissionSetLicenseId;
}
declare module "@salesforce/schema/PermissionSetLicenseAssign.Assignee" {
  const Assignee:any;
  export default Assignee;
}
declare module "@salesforce/schema/PermissionSetLicenseAssign.AssigneeId" {
  const AssigneeId:any;
  export default AssigneeId;
}
