declare module "@salesforce/schema/CaseTeamTemplateMember.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/CaseTeamTemplateMember.TeamTemplate" {
  const TeamTemplate:any;
  export default TeamTemplate;
}
declare module "@salesforce/schema/CaseTeamTemplateMember.TeamTemplateId" {
  const TeamTemplateId:any;
  export default TeamTemplateId;
}
declare module "@salesforce/schema/CaseTeamTemplateMember.Member" {
  const Member:any;
  export default Member;
}
declare module "@salesforce/schema/CaseTeamTemplateMember.MemberId" {
  const MemberId:any;
  export default MemberId;
}
declare module "@salesforce/schema/CaseTeamTemplateMember.TeamRole" {
  const TeamRole:any;
  export default TeamRole;
}
declare module "@salesforce/schema/CaseTeamTemplateMember.TeamRoleId" {
  const TeamRoleId:any;
  export default TeamRoleId;
}
declare module "@salesforce/schema/CaseTeamTemplateMember.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/CaseTeamTemplateMember.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/CaseTeamTemplateMember.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/CaseTeamTemplateMember.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/CaseTeamTemplateMember.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/CaseTeamTemplateMember.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/CaseTeamTemplateMember.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
