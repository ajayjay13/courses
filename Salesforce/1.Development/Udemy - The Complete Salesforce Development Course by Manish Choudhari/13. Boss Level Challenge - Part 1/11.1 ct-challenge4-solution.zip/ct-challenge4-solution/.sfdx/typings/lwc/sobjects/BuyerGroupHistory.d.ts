declare module "@salesforce/schema/BuyerGroupHistory.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/BuyerGroupHistory.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/BuyerGroupHistory.BuyerGroup" {
  const BuyerGroup:any;
  export default BuyerGroup;
}
declare module "@salesforce/schema/BuyerGroupHistory.BuyerGroupId" {
  const BuyerGroupId:any;
  export default BuyerGroupId;
}
declare module "@salesforce/schema/BuyerGroupHistory.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/BuyerGroupHistory.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/BuyerGroupHistory.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/BuyerGroupHistory.Field" {
  const Field:string;
  export default Field;
}
declare module "@salesforce/schema/BuyerGroupHistory.OldValue" {
  const OldValue:any;
  export default OldValue;
}
declare module "@salesforce/schema/BuyerGroupHistory.NewValue" {
  const NewValue:any;
  export default NewValue;
}
