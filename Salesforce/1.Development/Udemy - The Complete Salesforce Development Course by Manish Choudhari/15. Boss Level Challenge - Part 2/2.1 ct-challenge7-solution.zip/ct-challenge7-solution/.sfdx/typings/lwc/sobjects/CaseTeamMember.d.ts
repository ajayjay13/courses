declare module "@salesforce/schema/CaseTeamMember.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/CaseTeamMember.Parent" {
  const Parent:any;
  export default Parent;
}
declare module "@salesforce/schema/CaseTeamMember.ParentId" {
  const ParentId:any;
  export default ParentId;
}
declare module "@salesforce/schema/CaseTeamMember.Member" {
  const Member:any;
  export default Member;
}
declare module "@salesforce/schema/CaseTeamMember.MemberId" {
  const MemberId:any;
  export default MemberId;
}
declare module "@salesforce/schema/CaseTeamMember.TeamTemplateMember" {
  const TeamTemplateMember:any;
  export default TeamTemplateMember;
}
declare module "@salesforce/schema/CaseTeamMember.TeamTemplateMemberId" {
  const TeamTemplateMemberId:any;
  export default TeamTemplateMemberId;
}
declare module "@salesforce/schema/CaseTeamMember.TeamRole" {
  const TeamRole:any;
  export default TeamRole;
}
declare module "@salesforce/schema/CaseTeamMember.TeamRoleId" {
  const TeamRoleId:any;
  export default TeamRoleId;
}
declare module "@salesforce/schema/CaseTeamMember.TeamTemplate" {
  const TeamTemplate:any;
  export default TeamTemplate;
}
declare module "@salesforce/schema/CaseTeamMember.TeamTemplateId" {
  const TeamTemplateId:any;
  export default TeamTemplateId;
}
declare module "@salesforce/schema/CaseTeamMember.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/CaseTeamMember.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/CaseTeamMember.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/CaseTeamMember.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/CaseTeamMember.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/CaseTeamMember.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/CaseTeamMember.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
