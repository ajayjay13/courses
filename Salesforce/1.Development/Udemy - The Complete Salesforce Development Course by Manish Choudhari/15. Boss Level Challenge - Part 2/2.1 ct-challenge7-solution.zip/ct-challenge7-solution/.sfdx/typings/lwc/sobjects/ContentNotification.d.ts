declare module "@salesforce/schema/ContentNotification.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/ContentNotification.Nature" {
  const Nature:string;
  export default Nature;
}
declare module "@salesforce/schema/ContentNotification.Users" {
  const Users:any;
  export default Users;
}
declare module "@salesforce/schema/ContentNotification.UsersId" {
  const UsersId:any;
  export default UsersId;
}
declare module "@salesforce/schema/ContentNotification.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/ContentNotification.EntityType" {
  const EntityType:string;
  export default EntityType;
}
declare module "@salesforce/schema/ContentNotification.EntityIdentifier" {
  const EntityIdentifier:any;
  export default EntityIdentifier;
}
declare module "@salesforce/schema/ContentNotification.EntityIdentifierId" {
  const EntityIdentifierId:any;
  export default EntityIdentifierId;
}
declare module "@salesforce/schema/ContentNotification.Subject" {
  const Subject:string;
  export default Subject;
}
declare module "@salesforce/schema/ContentNotification.Text" {
  const Text:string;
  export default Text;
}
