declare module "@salesforce/schema/EmbeddedServiceLabel.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/EmbeddedServiceLabel.DurableId" {
  const DurableId:string;
  export default DurableId;
}
declare module "@salesforce/schema/EmbeddedServiceLabel.EmbeddedServiceConfigDeveloperName" {
  const EmbeddedServiceConfigDeveloperName:string;
  export default EmbeddedServiceConfigDeveloperName;
}
declare module "@salesforce/schema/EmbeddedServiceLabel.LabelKey" {
  const LabelKey:string;
  export default LabelKey;
}
declare module "@salesforce/schema/EmbeddedServiceLabel.CustomLabelName" {
  const CustomLabelName:string;
  export default CustomLabelName;
}
