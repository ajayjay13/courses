declare module "@salesforce/schema/ContactPointEmailHistory.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/ContactPointEmailHistory.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/ContactPointEmailHistory.ContactPointEmail" {
  const ContactPointEmail:any;
  export default ContactPointEmail;
}
declare module "@salesforce/schema/ContactPointEmailHistory.ContactPointEmailId" {
  const ContactPointEmailId:any;
  export default ContactPointEmailId;
}
declare module "@salesforce/schema/ContactPointEmailHistory.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/ContactPointEmailHistory.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/ContactPointEmailHistory.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/ContactPointEmailHistory.Field" {
  const Field:string;
  export default Field;
}
declare module "@salesforce/schema/ContactPointEmailHistory.OldValue" {
  const OldValue:any;
  export default OldValue;
}
declare module "@salesforce/schema/ContactPointEmailHistory.NewValue" {
  const NewValue:any;
  export default NewValue;
}
