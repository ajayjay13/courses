declare module "@salesforce/schema/ContentFolderMember.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/ContentFolderMember.ParentContentFolder" {
  const ParentContentFolder:any;
  export default ParentContentFolder;
}
declare module "@salesforce/schema/ContentFolderMember.ParentContentFolderId" {
  const ParentContentFolderId:any;
  export default ParentContentFolderId;
}
declare module "@salesforce/schema/ContentFolderMember.ChildRecord" {
  const ChildRecord:any;
  export default ChildRecord;
}
declare module "@salesforce/schema/ContentFolderMember.ChildRecordId" {
  const ChildRecordId:any;
  export default ChildRecordId;
}
declare module "@salesforce/schema/ContentFolderMember.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/ContentFolderMember.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
declare module "@salesforce/schema/ContentFolderMember.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/ContentFolderMember.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/ContentFolderMember.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/ContentFolderMember.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/ContentFolderMember.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/ContentFolderMember.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
