declare module "@salesforce/schema/ContactPointConsentHistory.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/ContactPointConsentHistory.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/ContactPointConsentHistory.ContactPointConsent" {
  const ContactPointConsent:any;
  export default ContactPointConsent;
}
declare module "@salesforce/schema/ContactPointConsentHistory.ContactPointConsentId" {
  const ContactPointConsentId:any;
  export default ContactPointConsentId;
}
declare module "@salesforce/schema/ContactPointConsentHistory.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/ContactPointConsentHistory.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/ContactPointConsentHistory.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/ContactPointConsentHistory.Field" {
  const Field:string;
  export default Field;
}
declare module "@salesforce/schema/ContactPointConsentHistory.OldValue" {
  const OldValue:any;
  export default OldValue;
}
declare module "@salesforce/schema/ContactPointConsentHistory.NewValue" {
  const NewValue:any;
  export default NewValue;
}
