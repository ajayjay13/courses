declare module "@salesforce/schema/UserPreference.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/UserPreference.User" {
  const User:any;
  export default User;
}
declare module "@salesforce/schema/UserPreference.UserId" {
  const UserId:any;
  export default UserId;
}
declare module "@salesforce/schema/UserPreference.Preference" {
  const Preference:string;
  export default Preference;
}
declare module "@salesforce/schema/UserPreference.Value" {
  const Value:string;
  export default Value;
}
declare module "@salesforce/schema/UserPreference.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
