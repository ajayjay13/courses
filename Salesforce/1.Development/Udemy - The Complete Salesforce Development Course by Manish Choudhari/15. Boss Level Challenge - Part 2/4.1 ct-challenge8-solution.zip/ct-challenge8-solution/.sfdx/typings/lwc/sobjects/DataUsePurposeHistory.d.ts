declare module "@salesforce/schema/DataUsePurposeHistory.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/DataUsePurposeHistory.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/DataUsePurposeHistory.DataUsePurpose" {
  const DataUsePurpose:any;
  export default DataUsePurpose;
}
declare module "@salesforce/schema/DataUsePurposeHistory.DataUsePurposeId" {
  const DataUsePurposeId:any;
  export default DataUsePurposeId;
}
declare module "@salesforce/schema/DataUsePurposeHistory.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/DataUsePurposeHistory.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/DataUsePurposeHistory.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/DataUsePurposeHistory.Field" {
  const Field:string;
  export default Field;
}
declare module "@salesforce/schema/DataUsePurposeHistory.OldValue" {
  const OldValue:any;
  export default OldValue;
}
declare module "@salesforce/schema/DataUsePurposeHistory.NewValue" {
  const NewValue:any;
  export default NewValue;
}
